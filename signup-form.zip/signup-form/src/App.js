import './App.css';
import Form from "./Form"

function App() {
return (
	<div className="App">
	<Form />
	</div>
	
);
}

export default App;
